I created three classes Library, Shelf, and Book and included different
variables for each class to be able to differentiate them apart. A library contains a name and has a list of shelves. A shelf has a name, shelf number, and a list of books on the shelf. A book has a name and whether it is checked out or not. 

I created some prototype functions to keep with the constructor plus prototype pattern to create projects. The prototypes create three functions that do the three things that a "student" would want to see the library do.

1) Check to see if the book is checked out. I go through all the books and check to see if the name sent in is the name of a book on all shelves in the library.

2) Return shelves, returns a list of all selves in the library

3) Create Library, creates a table of the shelves and books on the self

In the HTML file I created the library with a set number of books and shelves like it mentiones in the lab and then I test out the functions to see if they work as intended. 
